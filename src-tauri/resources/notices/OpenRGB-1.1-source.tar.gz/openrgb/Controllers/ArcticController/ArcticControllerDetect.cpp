/*---------------------------------------------------------*\
| ArcticControllerDetect.cpp                                |
|                                                           |
|   Detector for Arctic devices                             |
|                                                           |
|   Armin Wolf (Wer-Wolf)                       09 Jan 2023 |
|                                                           |
|   This file is part of the OpenRGB project                |
|   SPDX-License-Identifier: GPL-2.0-or-later               |
\*---------------------------------------------------------*/

#include <vector>
#include "ArcticController.h"
#include "DetectionManager.h"
#include "find_usb_serial_port.h"
#include "RGBController_Arctic.h"

#define CH341_VID   0x1A86
#define CH341_PID   0x7523

DetectedControllers DetectArcticControllers()
{
    DetectedControllers         detected_controllers;
    std::vector<std::string>    ports;

    ports = find_usb_serial_port(CH341_VID, CH341_PID);

    for(unsigned int device = 0; device < ports.size(); device++)
    {
        ArcticController *controller = new ArcticController(ports[device]);

        if(controller->IsPresent())
        {
            RGBController_Arctic *rgb_controller = new RGBController_Arctic(controller);
            detected_controllers.push_back(rgb_controller);
        }
        else
        {
            delete controller;
        }
    }

    return(detected_controllers);
}

REGISTER_DETECTOR("Arctic RGB controller", DetectArcticControllers);
REGISTER_CUSTOM_UDEV_RULE(arctic, "Arctic RGB controller", "SUBSYSTEMS==\"serial|hidraw\", ATTRS{idVendor}==\"1a86\", ATTRS{idProduct}==\"7523\", TAG+=\"uaccess\", TAG+=\"Arctic_RGB_controller\"");
